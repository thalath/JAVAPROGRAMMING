﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiddTerm_Exam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            txtPayment.ReadOnly = true;
        }
        
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtName.Text) || string.IsNullOrEmpty(txtAddress.Text) ||
                    string.IsNullOrEmpty(txtNewNum.Text) || string.IsNullOrEmpty(txtOldNum.Text))
                {
                    MessageBox.Show("Please enter your informatin into the text box fitst", "Information",
                                     MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    double oldNum, newNum, usage = 0, exchange = 4100;
                    oldNum = Double.Parse(txtOldNum.Text);
                    newNum = double.Parse(txtNewNum.Text);
                    string currency = "R";
                    if (oldNum > newNum)
                    {
                        MessageBox.Show("Wrong calculate please input num of new num bigger than old num",
                                        "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        usage = newNum - oldNum;
                    }
                    
                        WaterDesign ob = new WaterDesign();
                    txtPayment.Text = ob.paymentFun(0, usage).ToString("#,##0.00" + currency);
                    txtusage.Text = usage.ToString("#,##0.00" + " m3");
                    txtChangeRate.Text = exchange.ToString() ;
                    
                      

                }
            }catch(Exception){
                MessageBox.Show("Error code: ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
