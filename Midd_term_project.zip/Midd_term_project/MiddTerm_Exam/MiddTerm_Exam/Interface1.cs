﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiddTerm_Exam
{
    internal interface Interface1 
    {
        double paymentFun(double payment, double usage);
        string currencyFun(string currency);
    }
}