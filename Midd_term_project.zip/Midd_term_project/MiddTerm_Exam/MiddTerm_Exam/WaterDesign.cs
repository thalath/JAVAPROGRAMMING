﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiddTerm_Exam
{
    internal class WaterDesign : Interface1
    {
        public string currencyFun(string currency)
        {
            string currencySymbol = "";
            if (currency.Equals("Riel")){
                currencySymbol = "R";
            }else if(currency.Equals("Dollar")){
                currencySymbol= "$";
            }
            return currencySymbol;
        }

        public double paymentFun(double payment, double usage)

        {
             payment = 0;
            if (usage < 8)
            {
                return payment = 400;
            }
            else if (usage < 16)
            {
                return payment = 720;
            }
            else if (usage < 26)
            {
                return payment = 960;
            }else if(usage < 51)
            {
                return payment = 1250;
            }else if (usage < 101)
            {
                return payment = 1900;
            }else if (usage < 201)
            {
                return payment = 2200;
            }else if( usage > 200)
            {
                return payment =2500;
            }
            return payment;
        }

    }
}
