package com.example.salarytax;

public class ImplementSalaryInterface implements SalaryInterface{

    @Override
    public double netSalary(double grossSalary, double tax) {
        return grossSalary - tax;
    }

    @Override
    public double tax(double grossSalary) {
        double results = 0;
        if(grossSalary > 0 && grossSalary < 1500001){
            results=0;
        }else if (grossSalary >= 1_500_001 && grossSalary < 2_000_001){
            results=(grossSalary*0.05) - 75_000;
        }else if (grossSalary >= 2_000_001 &&  grossSalary < 8_500_001){
            results=(grossSalary*0.1) - 175_000;
        }else if (grossSalary >= 8_500_001 && grossSalary < 12_500_001){
            results=(grossSalary*0.15) - 600_000;
        }else if(grossSalary >= 12_500_001){
            results=(grossSalary*0.2) - 1_225_000;
        }
        return results;
    }
}
