package com.example.salarytax;

public interface SalaryInterface {
    public double netSalary(double grossSalary, double tax);
    public double tax(double grossSalary);
}
