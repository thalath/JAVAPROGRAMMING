package com.example.salarytax;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText edTax, edGrossSalary, edNetSalary;

    private Button btnOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edTax=findViewById(R.id.edTax);
        edNetSalary=findViewById(R.id.edNetSalary);
        edGrossSalary=findViewById(R.id.edGrossSalary);
        edTax.setFocusable(false);
        edTax.setFocusableInTouchMode(false);
        edTax.setInputType(InputType.TYPE_NULL);
        btnOK=findViewById(R.id.btnOK);
        btnOKValues();
    }
    private void btnOKValues(){
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double netSalary, grossSalary, tax = 0;
                grossSalary=Double.parseDouble(edGrossSalary.getText().toString());
                DecimalFormat t = new DecimalFormat("#,##០.00");
                ImplementSalaryInterface ob = new ImplementSalaryInterface();
                tax=ob.tax(grossSalary);
                netSalary=ob.netSalary(grossSalary, tax);

                edTax.setText(t.format(tax) + "Riels");
                edNetSalary.setText(t.format(netSalary) + "Riels");
            }
        });
    }

}