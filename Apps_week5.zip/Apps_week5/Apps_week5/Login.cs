﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apps_week5
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            txtpassword.UseSystemPasswordChar = true;
            txtpassword.MaxLength = 15;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtusername.Text.Equals("") || txtpassword.Text.Equals(""))
            {
                showMessage("Please input username or password into the textbox");
            }
            else
            {
                string username, password;
                username = txtusername.Text;
                password = txtpassword.Text;
                if (username.Equals("admin") && password.Equals("admin"))
                {
                    applications openApps = new applications();
                    openApps.Show();
                    this.Visible = false;
                    clears();
                }
                else
                {
                    showMessage("Invalid username or password");
                }
            }
        }
        
        private void showMessage(string sms)
        {
            MessageBox.Show(sms, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void clears()
        {
            txtusername.Text = "";
            txtpassword.Clear();
            txtusername.Focus();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPass.Checked)
            {
                txtpassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clears();
        }
    }
}
