﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apps_week5
{
    public partial class EDC : Form
    {
        public EDC()
        {
            InitializeComponent();
            txtPayment.ReadOnly = true;
            txtUsed.ReadOnly = true;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtID.Text) || string.IsNullOrEmpty(txtNewNum.Text) || string.IsNullOrEmpty(txtOldNum.Text))
            {
                MessageBox.Show("And run it again...!", "Informations");
            }
            else
            {
                double used, oldNum, newNum, payment;
                oldNum = Double.Parse(txtOldNum.Text);
                newNum = Convert.ToDouble(txtNewNum.Text);
                if(oldNum < newNum)
                {
                    EDCImplements obj = new EDCImplements();
                    used = newNum - oldNum;
                    payment = obj.payment(used);
                    txtPayment.Text = payment.ToString("#,##0.00" + "R");
                    txtUsed.Text = used.ToString("#,##0.00" + "kW");
                }
                else
                {
                    MessageBox.Show("New number must be greater than Old Number\n" +
                        "Please check and run it again...!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            
        }

       
    }
}
