﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apps_week5
{
    internal class EDCImplements : EDCInterface
    {
        public double payment(double used)
        {
            double result = 0.00;
            if(used >= 0 && used < 11)
            {
                result = used * 380;
            }else if(used >= 11 && used < 51)
            {
                result = ((used - 10) * 480) + 10 * 380;
            }else if (used >= 51 && used < 201)
            {
                result = ((used - 50) * 610) + (50 * 480) + (10 * 380);
            }else if(used >= 201)
            {
                result = ((used - 200) * 740) + (200 * 610) + (50 * 480) + (10 * 380);
            }

            return result;
        }
    }
}
