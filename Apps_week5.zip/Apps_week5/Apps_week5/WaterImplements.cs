﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apps_week5{
    internal class WaterImplements : waterInterface{
        public double payment(double used){
            double result = 0.00;
            if(used >= 0 && used < 8){
                result = used * 400;
            }else if(used >= 8 && used < 16){
                result = ((used - 7) * 720) + (7 * 400);
            }else if(used >= 16 && used < 26){
                result = ((used - 22) * 960) + (15 * 720) + (400 * 7);
            }else if(used >= 26 && used < 51){
                result = ((used - 47) * 1250) + (25 * 960) + (15 * 720) + (400 * 7);
            }else if(used >= 51 && used < 101){
                result = ((used - 97) * 1900) + (50 * 1250) + (25 * 960) + (15 * 720) + (400 * 7);
            }else if( used >= 101 && used < 201){
                result = ((used - 197) * 2200) + (100 * 1900) + (50 * 1250) + (25 * 960) + (15 * 720) + (400 * 7);
            }else if(used >= 201)
            {
                result = ((used - 297) * 2500) + (100 * 1900) + (50 * 1250) + (25 * 960) + (15 * 720) + (400 * 7) + (200 * 2200);
            }
                return result;
        }
    }
}
