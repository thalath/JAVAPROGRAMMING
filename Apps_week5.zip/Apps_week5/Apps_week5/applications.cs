﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apps_week5
{
    public partial class applications : Form
    {
        public applications()
        {
            InitializeComponent();
        }

        private void btnSumApps_Click(object sender, EventArgs e)
        {
            Calculator calc = new Calculator();
            calc.Show();
            this.Visible = false;
        }

        private void btnEDC_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            EDC app = new EDC();
            app.Show();
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WaterApp app = new WaterApp();
            app.Show();
            this.Visible = false;
        }
    }
}
