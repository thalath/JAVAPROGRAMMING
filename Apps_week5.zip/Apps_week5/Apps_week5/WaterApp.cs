﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apps_week5
{
    public partial class WaterApp : Form
    {
        public WaterApp()
        {
            InitializeComponent();
            txtPaymentInR.ReadOnly = true;
            txtUsage.ReadOnly = true;
            txtPaymentInD.ReadOnly = true;
        }

        private void WaterApp_Load(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtID.Text) || string.IsNullOrEmpty(txtName.Text) ||
                string.IsNullOrEmpty(txtNewNum.Text) || string.IsNullOrEmpty(txtOldNum.Text)){
                MessageBox.Show("Please Enter all your information into the textBox first...!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else{
                double OldNum, NewNum, paymentInRiel, paymentInDollar, used = 0;
                OldNum = Double.Parse(txtOldNum.Text);
                NewNum = Convert.ToDouble(txtNewNum.Text);
                
                WaterImplements obj = new WaterImplements();
                if(NewNum > OldNum){
                    used = NewNum - OldNum;
                    paymentInRiel = obj.payment(used);
                    paymentInDollar = paymentInRiel / 4100;
                    txtUsage.Text = used.ToString("#, ##0.00" + " m3");
                    txtPaymentInR.Text = paymentInRiel.ToString("#, ##0.00" + " R");
                    txtPaymentInD.Text = paymentInDollar.ToString("#, ##0.00" + " $");
                }
                else{
                    MessageBox.Show("The Value of new numbers must be greater than Old numbers...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtID.Clear();
            txtName.Clear();
            txtOldNum.Clear();
            txtNewNum.Clear();
            txtPaymentInR.Clear();
            txtPaymentInD.Clear();
            txtUsage.Clear();
        }
    }
}
