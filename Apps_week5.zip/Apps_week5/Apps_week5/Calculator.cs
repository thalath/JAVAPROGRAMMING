﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apps_week5
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
            this.Text = "Math Application";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(labelNum1.Text) || string.IsNullOrEmpty(txtNum2.Text))
            {
                showMessage("Please input value into the textbox");
            }
            else
            {
                try
                {
                    double num1, num2, result = 0;
                    num1 = Convert.ToDouble(txtNum1.Text);
                    num2 = double.Parse(txtNum2.Text);
                    result = num1 + num2;
                    showMessage(result.ToString());
                    clears();
                }catch(Exception ee)
                {
                    showMessage("please input valid integer.");
                    clears();
                }
            }
        }

        private void showMessage(string sms)
        {
            MessageBox.Show(sms, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            clears();
        }

        private void clears()
        {
            txtNum1.Text = "";
            txtNum2.Clear();
            txtNum1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNum1.Text) || string.IsNullOrEmpty(txtNum2.Text))
            {
                showMessage("Please input value into the texbox");
            }
            else
            {
                try
                {
                    double num1, num2, result = 0;
                    num1 = Convert.ToDouble(txtNum1.Text);
                    num2 = double.Parse(txtNum2.Text);
                    result = num1 - num2;
                    showMessage(result.ToString());
                }catch(Exception ee)
                {
                    showMessage("Please input valid integer.");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNum1.Text) || string.IsNullOrEmpty(txtNum2.Text))
            {
                showMessage("Please input value into the textbox");
            }
            else
            {
                try
                {
                    double num1, num2, result = 0;
                    num1 = Convert.ToDouble(txtNum1.Text);
                    num2 = double.Parse(txtNum2.Text);
                    result = num1 * num2;
                    showMessage(result.ToString());
                    clears();
                }catch(Exception ee)
                {
                    showMessage("Please Enter valid integer.");
                    clears();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txtNum1.Text.Equals("") || txtNum2.Text.Equals(""))
            {
                showMessage("Please input into textbox");
            }
            else
            {
                try
                {
                    double num1, num2, result = 0;
                    num1 = Convert.ToDouble(txtNum1.Text);
                    num2 = double.Parse(txtNum2.Text);
                    result = num1 / num2;
                    showMessage(result.ToString());
                    clears();
                }catch(Exception ee)
                {
                    showMessage("Please enter valid integer.");
                    clears();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            applications app = new applications();
            app.Show();
            this.Visible = false;
        }
    }
}
