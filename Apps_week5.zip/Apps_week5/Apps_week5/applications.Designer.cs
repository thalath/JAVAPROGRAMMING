﻿namespace Apps_week5
{
    partial class applications
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSumApps = new System.Windows.Forms.Button();
            this.btnEDC = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSumApps
            // 
            this.btnSumApps.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSumApps.Font = new System.Drawing.Font("Calisto MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSumApps.ForeColor = System.Drawing.Color.Black;
            this.btnSumApps.Location = new System.Drawing.Point(37, 37);
            this.btnSumApps.Name = "btnSumApps";
            this.btnSumApps.Size = new System.Drawing.Size(304, 54);
            this.btnSumApps.TabIndex = 1;
            this.btnSumApps.Text = "Sum Apps";
            this.btnSumApps.UseVisualStyleBackColor = false;
            this.btnSumApps.Click += new System.EventHandler(this.btnSumApps_Click);
            // 
            // btnEDC
            // 
            this.btnEDC.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnEDC.Font = new System.Drawing.Font("Calisto MT", 13.8F);
            this.btnEDC.Location = new System.Drawing.Point(347, 37);
            this.btnEDC.Name = "btnEDC";
            this.btnEDC.Size = new System.Drawing.Size(304, 54);
            this.btnEDC.TabIndex = 2;
            this.btnEDC.Text = "Time Date";
            this.btnEDC.UseVisualStyleBackColor = false;
            this.btnEDC.Click += new System.EventHandler(this.btnEDC_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button3.Font = new System.Drawing.Font("Calisto MT", 13.8F);
            this.button3.Location = new System.Drawing.Point(37, 126);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(304, 54);
            this.button3.TabIndex = 0;
            this.button3.Text = "EDC Apps";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button4.Font = new System.Drawing.Font("Calisto MT", 13.8F);
            this.button4.Location = new System.Drawing.Point(347, 126);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(304, 54);
            this.button4.TabIndex = 0;
            this.button4.Text = "Water Apps";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button5.Font = new System.Drawing.Font("Calisto MT", 13.8F);
            this.button5.Location = new System.Drawing.Point(37, 207);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(304, 54);
            this.button5.TabIndex = 0;
            this.button5.Text = "button1";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button6.Font = new System.Drawing.Font("Calisto MT", 13.8F);
            this.button6.Location = new System.Drawing.Point(347, 207);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(304, 54);
            this.button6.TabIndex = 0;
            this.button6.Text = "Hotel App";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.BurlyWood;
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.btnEDC);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.btnSumApps);
            this.groupBox1.Location = new System.Drawing.Point(51, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(696, 316);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Applications";
            // 
            // applications
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 368);
            this.Controls.Add(this.groupBox1);
            this.Name = "applications";
            this.Text = "applications";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSumApps;
        private System.Windows.Forms.Button btnEDC;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}