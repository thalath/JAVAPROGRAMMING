﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apps_week5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboType.Items.AddRange(new String[] { "VIP", "Normal", "President"});
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            double payment = 0;
            DateTime tstart = tStart.Value.Date;
            DateTime tend = tEnd.Value.Date;
            TimeSpan tm;
            int livNum = 0, bookingNum = 0, price = 0;
            string room_type = "", days = "";
            bookingNum = Int32.Parse(txtBookingNum.Text);
            room_type = comboType.Text;
            if (room_type.Equals("VIP"))
            {
                price = 100;
            }else if(room_type == "Normal")
            {
                price = 50;
            }else if (room_type == "President")
            {
                price = 1000;
            }

            if (tstart < tend)
            {
                MessageBox.Show("Invalid input of data \n Please try again to check it");

            }
            else
            {
                tm = tend - tstart;
                livNum = tm.Days;

                payment = price * livNum * bookingNum;
                txtlivNum.Text = livNum + days;
                

            }
        }

        
    }
}
