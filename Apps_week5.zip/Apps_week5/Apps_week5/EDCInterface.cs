﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apps_week5
{
    internal interface EDCInterface
    {
        double payment(double used);
    }
}
