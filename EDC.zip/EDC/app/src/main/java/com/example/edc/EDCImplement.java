package com.example.edc;

public class EDCImplement implements EDCInterface{

    @Override
    public double payment(double used) {
        double result = 0.00;
        if(used >= 0 && used < 11){
            result = used * 380;
        }else if(used >= 11 && used < 51){
            result = ((used - 10) * 480) + (7 * 380);
        }else if(used >= 51 && used < 201){
            result = ((used - 50) * 610) + (50 * 480) + (7 * 380);
        }else if(used >= 201){
            result = ((used - 200) * 740) + (200 * 610) + (50 * 480) + (7 * 380);
        }
        return result;
    }
}
