package com.example.edc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText edNewNum, edOldNum, edPayment, edUsed;
    private Button btnOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edNewNum = findViewById(R.id.edNewNum);
        edOldNum = findViewById(R.id.edOldNum);
        edPayment = findViewById(R.id.edPayment);
        edUsed = findViewById(R.id.edUsed);
        btnOK = findViewById(R.id.btnOK);
//        values();
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double old, New, payment, used;
                old = Double.parseDouble(edOldNum.getText().toString());
                New = Double.parseDouble(edNewNum.getText().toString());
                used = New - old;
                EDCImplement obj = new EDCImplement();
                DecimalFormat t = new DecimalFormat("#.##0.00");
                payment = obj.payment(used);
                edUsed.setText(t.format(used) + "kW");
                edPayment.setText(t.format(payment) + "R");
            }
        }) ;
    }
//    private void values(){
//
//    }
}