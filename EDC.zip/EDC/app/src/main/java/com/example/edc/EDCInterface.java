package com.example.edc;

public interface EDCInterface {
    public double payment(double used);
}
