package OOP;

// 6.1 implement student class extends from the person class
public class Student extends Person{

    //7.1. Add property
    int grade;
    int age;


    public Student(String firstName,  String lastName){
        super(firstName, lastName);
    }

    // 7.2. Add a constructor to student
    public Student(String firstName, String lastName, int grade, int age){
        super(firstName, lastName);
        this.grade = grade;
        this.age = age;
    }
    //    7.3. prints overrides of student class
    public void printStudent(){
        System.out.println("Your name is " + firstName + " " + lastName);
        System.out.println("Yor are "+ age + "years old");
        System.out.println("Your are study at grade " + grade);
    }
    // main class
    public static void main(String[] args){
        Student s = new Student("Kosal", "Meta");
        Student s1 = new Student("Neary", "Tep", 97, 24);

        System.out.println(s.getFirstName());
        System.out.println(s.getLastName());
        s.printName();
        System.out.println("-----Override prints-------");
        s1.printStudent();

    }
}
