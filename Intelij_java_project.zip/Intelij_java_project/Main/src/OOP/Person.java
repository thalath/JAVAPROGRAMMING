package OOP;

public class Person {
    public String firstName, lastName;
    public Person(String fn, String ln){
        firstName = fn;
        lastName = ln;
    }
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public void printName(){
        System.out.println(firstName + " " + lastName);
    }
}
