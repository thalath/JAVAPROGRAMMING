package OOP;

public class TestPerson {

    public static void main(String[] args) {
        Person n = new Person("Sok", "Chet");
        Person n1 = new Person("Neary", "Tep");
        System.out.println(n.firstName);
        System.out.println(n1.firstName);
        System.out.println(n.getFirstName()+ " " + n1.lastName);
    }
}
