package intro;

public class Hello {
    public static void main(String []arg){
        System.out.println("Welcome to Java");
    }


}

class Product {
    Integer id;
    String title;
    Double voter;
    Double rate;
    Double discount;

    public Product(Integer id, String title, Double voter, Double rate, Double discount) {
        this.id = id;
        this.title = title;
        this.voter = voter;
        this.rate = rate;
        this.discount = discount;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", voter=" + voter +
                ", rate=" + rate +
                ", discount=" + discount +
                '}';
    }
}
