package fundamentals;

public class OOP{
    public static void main(String[] args) {
        Dog n = new Dog("KIKI", 25);
        n.print();
    }
}

class Dog{
    String name;
    int age;
    public Dog(String name, int age){
        this.name = name;
        this.age = age;
    }
    void print(){
        System.out.println("Hello " + name  + " Your age is " + age + " years old");
    }
}