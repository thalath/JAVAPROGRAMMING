package fundamentals;

public class score_compute {
    public static void main(String[] args) {
        // print a score by using control flow (if condition, if-else condition, if else-if else condition)
        int score=85;
        if ( score <= 100 && score >= 95){
            System.out.println("Socre is A");
        }else if(score < 95 && score >= 85){
            System.out.println("Score is B");
        }else if(score < 85 && score >= 75){
            System.out.println("Score is C");
        }else if(score < 75 && score >= 65){
            System.out.println("Score is D");
        }else if(score < 65 && score >= 55){
            System.out.println("Score is E");
        }else {
            System.out.println("Score is F");
        }
    }
}
