package fundamentals;

public class Loop {
    public static void main(String[] args) {
        // print even and odd numbers of an array by using loops and if else
        int[] num = {23, 30, 45, 17, 50};
        System.out.println(" \n------Assignment of array------");
        System.out.print("Array of nums = {");
        for(int index = 0; index < num.length; index++){
            System.out.print(num[index]+ " " );
        }
        System.out.println("}");
        System.out.print("The even number is ");
        for (int index = 0; index < num.length; index++){
            if(num[index]%2 == 0){
                System.out.print(num[index] + " ");
            }
        }
        System.out.println();
        System.out.print("The odd numbers is ");
        for (int index = 0; index<num.length; index++){
            if (num[index]%2 != 0){
                System.out.print(num[index] + " ");
            }
        }
    }
}
