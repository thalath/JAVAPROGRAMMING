package fundamentals;

public class Type {
    public static void main(String a[]) { //method
        int age = 20;
        final float PI = 3.1415f;
        char letter = 'A';
        boolean isTrue = true;
        double BigNum = 40.000_000_000_00f;
        System.out.println("int = " + age);
        System.out.println("Float = " + PI);
        System.out.println("char = " + letter);
        System.out.println("Boolean = " + isTrue);
        System.out.println("Double = " + BigNum);
    }
}
