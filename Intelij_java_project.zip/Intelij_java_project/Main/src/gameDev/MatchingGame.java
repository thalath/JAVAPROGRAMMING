package gameDev;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JTextField;


public class MatchingGame extends JFrame{
    JLabel ob = new JLabel("Hello ");
    JLabel ob2 = new JLabel("Hello ");
    JLabel ob3 = new JLabel("Hello ");
    JTextField tf = new JTextField(10);
    JTextField tf2 = new JTextField(10);
    public MatchingGame(){

        setLayout(new GridLayout(3,2, 10, 2));

        add(ob);
        add(tf);
        add(ob2);
        add(tf2);

        add(ob3);


        ob.setForeground(Color.blue);
        setVisible(true);
        setLocationRelativeTo(null);
        setSize(500, 300);
    }

    public static void main(String[] args){
        new MatchingGame();

    }
}
