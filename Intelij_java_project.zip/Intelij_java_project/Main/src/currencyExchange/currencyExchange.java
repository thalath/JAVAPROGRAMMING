package currencyExchange;

import javax.swing.*;
import javax.swing.border.Border;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class currencyExchange extends JFrame {
    JPanel all = new JPanel(new BorderLayout());
    JLabel currencySymbol = new JLabel("Rate 1$=");
    JLabel riel = new JLabel("Riels");
    JTextField tfRate = new JTextField(15);
    JPanel flow = new JPanel();
    JPanel grid = new JPanel();

    private final String[] currency = {"Dollar", "Riel", "Ero"};
    JComboBox combo1 = new JComboBox(currency);
    JComboBox combo2 = new JComboBox(currency);

    JTextField tf1 = new JTextField(15);
    JTextField tf2 = new JTextField(15);

    public currencyExchange(){

        layoutComponent();

        pack();
//        setSize(375, 175);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void layoutComponent(){
        Border border = BorderFactory.createEmptyBorder(10,10,10,10);
        flow.setLayout(new FlowLayout());
        flow.add(currencySymbol);
        tfRate.setText("4100");
        flow.add(tfRate);
        flow.add(riel);

        grid.setLayout(new GridLayout(2,2,3,3));
        grid.add(tf1);
        grid.add(combo1);grid.add(tf2) ;grid.add(combo2);
        all.add(flow, BorderLayout.NORTH);
        all.add(grid, BorderLayout.CENTER);
        all.setBorder(border);

        add(all);
        tf1.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                convert(tf1, tf2, combo1, combo2);
            }
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if(!Character.isDigit(c) && c!='.'){
                    e.consume();
                }
                if (c == '.' && tf1.getText().contains(".")) {
                    e.consume(); // block more than one dot
                }
            }
        });

        tf2.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                convert(tf2, tf1, combo2, combo1);
            }
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if(!Character.isDigit(c) && c!='.'){
                    e.consume();
                }
                if (c == '.' && tf1.getText().contains(".")) {
                    e.consume(); // block more than one dot
                }
            }
        });

        tfRate.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                convert(tf1, tf2, combo1, combo2);
            }
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if(!Character.isDigit(c) && c!='.'){
                    e.consume();
                }
                if (c == '.' && tf1.getText().contains(".")) {
                    e.consume(); // block more than one dot
                }
            }
        });

        combo1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convert(tf2, tf1, combo2, combo1);
            }
        });

        combo2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convert(tf1, tf2, combo1, combo2);
            }
        });

    }

    final int DOLLAR = 0, RIEL = 1;
    private void convert(JTextField text1, JTextField text2, JComboBox com1, JComboBox com2){

        int index1 = com1.getSelectedIndex();
        int index2 = com2.getSelectedIndex();

        float getRate = Float.parseFloat(tfRate.getText());

        if (index1 == index2 || text1.getText().isEmpty()){
            text2.setText(text1.getText());
            return;
        }
        switch (index1){
            case DOLLAR:
                if(index2==RIEL){
                    String sText1 = text1.getText();
                    float fText1 = Float.parseFloat(sText1);
                    fText1 *= getRate;
                    sText1=Float.toString(fText1);
                    text2.setText(sText1);
                }break;

            case RIEL:
                if (index2 == DOLLAR){
                    String sText1 = text1.getText();
                    float fText1 = Float.parseFloat(sText1);
                    fText1 /= getRate;
                    sText1=Float.toString(fText1);
                    text2.setText(sText1);
                }
                break;
        }
    }


    public static void main(String[] args) {
        new currencyExchange();
    }
}
