package currencyExchange;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class JComboBoxExample extends JFrame {
    private final String currency[] = {"Riels", "Dollars", "Euros"};
    JComboBox combo = new JComboBox(currency);
    JLabel dolarr = new JLabel("Currency: ");
    public JComboBoxExample(){
        setLayout(new FlowLayout());
        add(dolarr);
        add(combo);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(350, 175);
        setLocationRelativeTo(null);
        setVisible(true);

        // handle events
        combo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                System.out.println("\nIndex: " + combo.getSelectedIndex() + "\nItem: " + combo.getSelectedItem());
            }
        });
    }

    public static void main(String[] args) {
        new JComboBoxExample();
    }
}
