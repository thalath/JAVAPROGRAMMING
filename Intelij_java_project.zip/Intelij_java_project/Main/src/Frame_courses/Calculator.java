package Frame_courses;

import javax.swing.*;
import java.awt.*;

public class Calculator extends JPanel {
    public Calculator(){
        setLayout(new GridLayout(3,3,5,5));
        JButton[] btn = new JButton[10];
        for(int i = 0; i < btn.length; i++){
            btn[i] = new JButton(""+ i);
            btn[i].setFocusable(false);
        }
        for(int i = 0; i < btn.length; i++){
            add(btn[i]);
        }
    }
}
