package Frame_courses;

import javax.swing.JFrame;

public class CalculatorFrame extends JFrame {
    public CalculatorFrame(){
        add(new Calculator());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 400);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
