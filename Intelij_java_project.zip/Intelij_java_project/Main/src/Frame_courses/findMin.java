package Frame_courses;


import javax.print.attribute.standard.JobMessageFromOperator;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

public class findMin{
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        JLabel lbUsername = new JLabel("username: ");
        lbUsername.setBounds(20, 20, 100, 25);
        JTextField username = new JTextField();
        username.setBounds(90, 20, 150, 20);
        JLabel lbPassword = new JLabel("Password");
        lbPassword.setBounds(20, 45, 100, 20);
        JPasswordField password = new JPasswordField();
        password.setBounds(90, 45, 150, 25);
        JLabel print = new JLabel();
        print.setBounds(20, 140, 240, 100);
        JButton btnLogin = new JButton("Login");
        btnLogin.setFocusable(false);
        btnLogin.setBounds(100, 80, 80, 30);


        frame.setLayout(null);

        frame.add(lbUsername);
        frame.add(username);
        frame.add(lbPassword);
        frame.add(password);
        frame.add(btnLogin);
        frame.add(print);



        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 400);
        frame.setLocationRelativeTo(null);
    }
}