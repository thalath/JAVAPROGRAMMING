package Frame_courses;

public class CalculatorMain {
    public static void main(String[] args) {
        new CalculatorFrame();
    }
}
