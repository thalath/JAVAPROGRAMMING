package Frame_courses;

public class Person {
    private String name;
    private Integer age;
    private Integer car;

    public Person(String name, Integer car, Integer age) {
        this.name = name;
        this.car = car;
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public void setCar(Integer car) {
        this.car = car;
    }

    public String getName() {
        return name;
    }

    public Integer getCar() {
        return car;
    }

    public Integer getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", car=" + car +
                '}';
    }
}
