package Frame_courses;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;


// Objective JFrame and JLabel courses

public class new_frame {
    public static void main(String[] args){

        ImageIcon image = new ImageIcon("dog.jpg");

        JLabel label = new JLabel(); // create label
        label.setText("Hello world"); // set text of label
        label.setFont(new Font("MV Boli", Font.BOLD, 20));  // set Font style
        label.setIcon(image);  // set image but just bug
        label.setForeground(new Color(0xA429AC)); //set font color of text



        JFrame frame = new JFrame(); // create frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 300);
        frame.setLocation(400, 100);
        frame.add(label);
        frame.setTitle("Hello first JFrame");
        frame.setVisible(true);



    }
}