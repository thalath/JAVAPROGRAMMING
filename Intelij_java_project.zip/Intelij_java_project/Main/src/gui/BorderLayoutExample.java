package gui;

import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.BorderLayout;

public class BorderLayoutExample extends JFrame{

    JButton[] btn = new JButton[6];

    public BorderLayoutExample(){

        setLayout(new BorderLayout());

        for(int i = 0; i < btn.length; i++){
            btn[i] = new JButton(""+(i + 1));
            btn[i].setFocusable(false);
            btn[i].setForeground(Color.blue);
            btn[i].setBackground(Color.cyan);
        }

        btn[0].setBackground(Color.ORANGE);

        add(btn[0], BorderLayout.CENTER);
        add(btn[1], BorderLayout.WEST);
        add(btn[2], BorderLayout.EAST);
        add(btn[3], BorderLayout.SOUTH);
        add(btn[4], BorderLayout.NORTH);

        setSize(300, 175);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args){
        new BorderLayoutExample();
    }

}
