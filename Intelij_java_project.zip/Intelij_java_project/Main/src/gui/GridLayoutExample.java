package gui;

import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.GridLayout;

public class GridLayoutExample extends JFrame {

    JButton b[] = new JButton[6];

    public GridLayoutExample(){

        setLayout(new GridLayout(3, 2, 5, 8));


        for (int i = 0; i<b.length; i++){
            b[i] = new JButton("" +(i + 1));
            add(b[i]);
        }

        setSize(350, 175);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args){
        new GridLayoutExample();
    }
}
