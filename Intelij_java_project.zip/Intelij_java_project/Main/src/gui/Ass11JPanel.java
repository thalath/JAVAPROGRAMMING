package gui;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;

public class Ass11JPanel extends JFrame{

    JLabel labelName = new JLabel("Name", JLabel.CENTER);
    JLabel labelPassword = new JLabel("Password: ", JLabel.CENTER);
    JTextField tfName = new JTextField(10);
    JPasswordField tfPassword = new JPasswordField(10);
    JButton btnLogin = new JButton("Login");

    public Ass11JPanel(){

//        Border border = BorderFactory.createEmptyBorder(20, 20, 10,10);

        JPanel gridPanel = new JPanel(new GridLayout(2,2,5,5));
        gridPanel.add(labelName); gridPanel.add(tfName);
        gridPanel.add(labelPassword); gridPanel.add(tfPassword);
        gridPanel.setBorder(new LineBorder(Color.GREEN, 5)); Border border1 = gridPanel.getBorder();

        JPanel flowPanel = new JPanel(new FlowLayout());
        flowPanel.setBorder(new LineBorder(Color.GREEN, 5));
        Border border = flowPanel.getBorder();
        flowPanel.setBorder(border);
        flowPanel.add(btnLogin);

        Border border2 = BorderFactory.createEmptyBorder(20, 20, 20, 20);
        JPanel allPanel = new JPanel(new BorderLayout());
        allPanel.setBorder(new LineBorder(Color.red, 5));border2 = allPanel.getBorder();
        allPanel.add(gridPanel, BorderLayout.CENTER);
        allPanel.add(flowPanel, BorderLayout.SOUTH);



        // set frame
        add(allPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(370, 190);
        setLocationRelativeTo(null);
        setVisible(true);
    }


    public static void main(String[] args) {
        new Ass11JPanel();
    }
}