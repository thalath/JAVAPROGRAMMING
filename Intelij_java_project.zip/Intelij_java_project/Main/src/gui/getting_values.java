package gui;

import javax.swing.JFrame;
import java.awt.*;

public class getting_values {
    public static void main(String[] args) {
        //1. Implement The simple frame
        JFrame frame = new JFrame();

        //2. setSize and Location in the JFrame.
        frame.setSize(100, 100);
        frame.setLocation(100, 100);


        // 3.1. getting width and height from frame's size;
        frame.getSize();
        Dimension dimension = frame.getSize();
        System.out.println("\n------Getting width and height from JFrame-----");
        System.out.println("Width of frame size is " + dimension.width);
        System.out.println("Height of frame's size is " + dimension.height);

        //3.2. getting x and y from location of frame
        frame.getLocation();
        Point point = frame.getLocation();
        System.out.println("\n--------Getting x and y from frame Locations---------");
        System.out.println("The hex of frame is " + point.x);
        System.out.println("The Y of frame is " + point.y);
    }
}
