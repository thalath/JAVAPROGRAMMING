package gui;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.FlowLayout;

public class ex2layout extends JFrame{

    JTextField tf = new JTextField(10);
    JButton btnOK = new JButton("OK");
    JLabel label = new JLabel("username: ");


   public ex2layout(){

       setBackground(Color.green);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setLayout( new FlowLayout(FlowLayout.LEFT));
       add(label);
       add(tf);
       add(btnOK);


       setVisible(true);
       setLocation(100, 100);
       setSize(400, 300);
       setResizable(false);
   }

   public static void main(String[] args){
       new ex2layout();
   }
}
