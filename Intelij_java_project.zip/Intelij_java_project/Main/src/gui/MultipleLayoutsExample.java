package gui;

import javax.swing.*;
import javax.swing.border.Border;


import java.awt.*;

public class MultipleLayoutsExample extends JFrame{
    JLabel labelName = new JLabel("Name", JLabel.CENTER);
    JTextField tf = new JTextField(10);
    JLabel labelPass = new JLabel("Password", JLabel.CENTER);
    JPasswordField passf = new JPasswordField(10);
    JButton btn = new JButton("Login");

    public MultipleLayoutsExample(){
        JPanel allPanel = new JPanel(new BorderLayout());

        JPanel gridPanel = new JPanel(new GridLayout(2,2,5,5));
        gridPanel.add(labelName); gridPanel.add(tf);
        gridPanel.add(labelPass); gridPanel.add(passf);
        allPanel.add(gridPanel, BorderLayout.CENTER);
        gridPanel.setBackground(Color.green);
        tf.setBackground(Color.CYAN);
        add(allPanel);

        Border border = BorderFactory.createEmptyBorder(15, 10, 15, 15);

        allPanel.setBorder(border);

        JPanel flowPanel =new JPanel(new FlowLayout());
        flowPanel.add(btn);
        flowPanel.setBackground(Color.MAGENTA);
        allPanel.add(flowPanel, BorderLayout.SOUTH);
        setSize(350, 175);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MultipleLayoutsExample();
    }
}
