package gui;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.GridLayout;
import java.awt.Color;

public class Ass10GridLayout extends JFrame {

    // created label, textField and button
    JButton btn = new JButton("Login");
    JLabel name = new JLabel("Name", JLabel.RIGHT);
    JTextField field = new JTextField(10);
    JLabel password = new JLabel("Password", JLabel.RIGHT);
    JTextField field2 = new JTextField(10);

    //constructor of JFrame
    public Ass10GridLayout(){

        // setGridLayout and size of frame
        setLayout(new GridLayout(3, 2, 2,7));
        setLocationRelativeTo(null);
        setSize(350, 180);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 50, 300, 180);

        // coloring the textField and label
        field.setBackground(Color.lightGray);
        field2.setBackground(Color.lightGray);
        name.setForeground(Color.BLUE);
        password.setForeground(Color.BLUE);

        // added items into the frame
        add(name);
        add(field);
        add(password);
        add(field2);
        add(btn);

        // setVisible of frame
        setVisible(true);
    }

    // main function to handle and run its whole code
    public static void main(String[] args){
        new Ass10GridLayout();
    }
}
