package gui;

import javax.swing.JFrame;
public class ExJFrame{
    public static void main(String[] args) {
        JFrame jframe = new JFrame();
        jframe.setTitle("A Simple JFrame");
        String JFrameTitle = jframe.getTitle();
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setVisible(true);
        jframe.setSize(400, 400);
        jframe.setLocation(200, 400);


        System.out.println("\n-----Print the values that get from JFrame to console----\n");
        System.out.println(jframe.getLocation());
        System.out.println(jframe.getSize());
        System.out.println(jframe.getTitle());
    }
}
