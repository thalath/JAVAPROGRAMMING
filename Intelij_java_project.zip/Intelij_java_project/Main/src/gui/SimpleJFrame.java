package gui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

class label extends JLabel{
    public label(){
        setText("Hello world");
        setHorizontalAlignment(JLabel.CENTER);
        setForeground(new Color(0xDC0337));

    }
}

public class SimpleJFrame extends JFrame {
    public SimpleJFrame(){
        setTitle("A first Title");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(100, 100);

        getContentPane().setBackground(new Color(0xA429AC));
        setVisible(true);
    }

    public static void main(String[] args) {
        SimpleJFrame frame = new SimpleJFrame();
        label b = new label();
        frame.add(b);
    }
}
