package gui;

import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.FlowLayout;

public class FlowLayoutExample extends JFrame {

    JLabel label = new JLabel("Name");
    JTextField field = new JTextField(10);
    JButton btnOK = new JButton("OK");




    public FlowLayoutExample(){
        String text = btnOK.getText();
        btnOK.setText(text);
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout(FlowLayout.LEFT));
        add(label);
        add(field);
        add(btnOK);

        setVisible(true);
    }
    public static void main(String[] args){
        new FlowLayoutExample();
    }
}
