package events;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionListenerAssignment12 extends JFrame implements ActionListener {
    JLabel lbName = new JLabel("Name: ");
    JTextField tfName = new JTextField(15);
    JButton btnOK = new JButton("OK");
    JLabel txt = new JLabel("your result are on the console");
    JLabel txt1 = new JLabel("after your clicked on OK");
    public ActionListenerAssignment12(){
        setLayout(new FlowLayout());
        add(lbName);
        add(tfName);
        btnOK.setFocusable(false);
        add(btnOK);
        add(txt);
        add(txt1);

        btnOK.addActionListener(this);

        setLocationRelativeTo(null);
        setSize(300, 180);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String input = tfName.getText();
        System.out.println(input);
    }

    public static void main(String[] args) { new ActionListenerAssignment12();}


}
