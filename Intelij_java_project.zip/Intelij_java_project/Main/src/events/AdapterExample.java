package events;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class AdapterExample extends JFrame {
    JLabel lbName = new JLabel("Name");
    JTextField tfName = new JTextField(20);
    JButton btnOK = new JButton("OK");
    JButton btnCancel = new JButton("Cancel");

    public AdapterExample(){
        add(lbName);
        add(tfName);
        add(btnOK);
        add(btnCancel);
        setFocusable(false);

        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Hello you clicked on btn cancel");
            }
        });

        btnOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Hello you clicked btnOK");
            }
        });

        tfName.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                System.out.println(tfName.getText());
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);
        setSize(300, 200);
        setVisible(true);
    }

    public static void main(String[] args) {
        new AdapterExample();
    }
}
