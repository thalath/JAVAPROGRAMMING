package events;

import javax.swing.*;
import java.awt.event.*;

public class asst13Adapter extends JFrame {
    public static void main(String[] args) {
        new asst13Adapter();
    }

    public asst13Adapter(){

        setLayout(null);
        JLabel lbName = new JLabel("Name: ");
        lbName.setBounds(20,10, 100, 20);
        JTextField tfName = new JTextField();
        tfName.setBounds(70,10, 150, 20);
        JButton btnOK = new JButton("OK");
        btnOK.setBounds(220, 9, 60, 20);
        JLabel print = new JLabel();
        print.setBounds(60, 70, 200, 20);

        btnOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                print.setText("Hello World");
                System.out.println(tfName.getText());
                tfName.setText(null);
            }
        });

        tfName.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {
                print.setText(tfName.getText());
            }
        });
        add(lbName);
        add(tfName);
        add(btnOK);
        add(print);
        setSize(310, 150);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
