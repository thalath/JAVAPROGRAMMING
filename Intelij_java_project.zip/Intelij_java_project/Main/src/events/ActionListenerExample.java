package events;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionListenerExample extends JFrame implements ActionListener {

    JLabel lb = new JLabel("Name");
    JTextField tf = new JTextField();
    JButton btn = new JButton("OK");


    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println(tf.getText());
    }

    public static void main(String[] args) {
        new ActionListenerExample();
    }

    public ActionListenerExample(){
        setLayout(new FlowLayout());
        btn.setFocusable(false);
        tf.setColumns(15);
        add(lb);
        add(tf);
        add(btn);

        btn.addActionListener(this);

        setSize(300, 200);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
