package com.example.scoremanagermentsystem;

public interface ScoreInterface {
    public double total(double html, double c, double java, double php, double sql);
    public String grade(double scores);

    public double avg(double total, int subNum);
}
