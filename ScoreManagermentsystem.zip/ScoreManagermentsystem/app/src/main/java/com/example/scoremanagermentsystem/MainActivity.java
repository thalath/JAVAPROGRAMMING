package com.example.scoremanagermentsystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    public EditText edHTML, edJAVA, edC, edPHP, edSQL, edAvg, edGrade, edTotal;
    public Button btnOK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
            edHTML=findViewById(R.id.edHTML);
            edJAVA=findViewById(R.id.edJAVA);
            edC=findViewById(R.id.edC);
            edPHP=findViewById(R.id.edPHP);
            edSQL=findViewById(R.id.edSQL);
            edTotal=findViewById(R.id.edTotal);
            edAvg=findViewById(R.id.edAvg);
            edGrade=findViewById(R.id.edGrade);
            btnOK=findViewById(R.id.btnOK);
            value();
    }
    public void value(){
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double avg, total;
                String grade;
                double html, java, C, php, sql;
                ImplementWScoreInterface ob = new ImplementWScoreInterface();
                DecimalFormat t = new DecimalFormat("###.00");
                html=Double.parseDouble(edHTML.getText().toString());
                java=Double.parseDouble(edJAVA.getText().toString());
                C=Double.parseDouble(edC.getText().toString());
                php=Double.parseDouble(edPHP.getText().toString());
                sql=Double.parseDouble(edSQL.getText().toString());
                total=ob.total(html, java, C, php, sql);

                avg=ob.avg(total, 5);
                grade=ob.grade(avg);

                edTotal.setText(t.format(total)+"Point");
                edAvg.setText(t.format(avg) + "%");
                edGrade.setText(grade);
            }
        });
    }
}