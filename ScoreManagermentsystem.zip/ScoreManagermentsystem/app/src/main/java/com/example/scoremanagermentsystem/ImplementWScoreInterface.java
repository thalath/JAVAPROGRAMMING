package com.example.scoremanagermentsystem;

public class ImplementWScoreInterface implements ScoreInterface{
    @Override
    public double total(double html, double c, double java, double php, double sql) {
        return html+c+java+php+sql;
    }

    @Override
    public String grade(double scores) {
        String results= "";
        if (scores >= 0 && scores < 50){
            results="F";
        } else if (scores >= 50 && scores < 60) {
            results="E";
        } else if (scores >= 60 && scores < 70) {
            results="D";
        } else if (scores >= 70 && scores < 80) {
            results="C";
        } else if (scores >= 80 && scores < 90) {
            results="B";
        } else if (scores >= 90 && scores <= 100) {
            results="A";
        }else {
            results="Invalid Input";
        }
        return results;
    }

    @Override
    public double avg(double total, int subNum) {
        return total/subNum;
    }
}
