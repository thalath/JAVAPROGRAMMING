package com.example.myapplication;

public class implementWaterInterface implements waterInterface{
    @Override
    public double paymentInRiel(double used) {
        double results = 0.0;
        if(used >0 && used <= 7){
            results=(400 * used);
        } else if (used > 7 && used <= 15) {
            results=(720*(used-7)) + (400*7);
        } else if (used > 15 && used <= 25) {
            results=((used-15)*960) + (400*7) + (15*720);
        } else if (used > 25 && used <= 50) {
            results=((used-22)*1250) + (400*7) + (15*720) + (25*960);
        } else if (used > 50 && used <= 100) {
            results=((used-50)*1900)+ (50*1250) + (400*7) + (15*720) + (25*960);
        } else if (used > 100 && used < 200) {
            results = ((used-100)*2200) + (100*1900)+ (50*1250) + (400*7) + (15*720) + (25*960);
        } else if (used > 200) {
            results = ((used-200)* 2500) + (200*2200) + (100*1900)+ (50*1250) + (400*7) + (15*720) + (25*960);
        }

        return results;
    }

    @Override
    public double paymentInDollar(double riel) {
        return riel / 4000;
    }

    @Override
    public double totalPayment(double payment, double waterMaintenance) {
        return payment + waterMaintenance;
    }


}
