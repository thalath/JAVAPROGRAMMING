package com.example.myapplication;

public interface waterInterface {
    public double paymentInRiel(double used);
    public double paymentInDollar(double used);
    public double totalPayment(double payment, double waterMaintenance);

}
