package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    public EditText edOldNum, edNewNum, edPayment, edRPayment, edDPayment, edUsed, edMaintenance;
    public Button btnOK, btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edNewNum=findViewById(R.id.edNewNum);
        edOldNum=findViewById(R.id.edOldNum);
        edMaintenance=findViewById(R.id.edwater);
        edUsed=findViewById(R.id.edUsed);
        edPayment=findViewById(R.id.edPayment);
        edRPayment=findViewById(R.id.edRPayment);
        edDPayment=findViewById(R.id.edDPayment);
        edUsed=findViewById(R.id.edUsed);
        btnOK=findViewById(R.id.btnOk);
        btnCancel=findViewById(R.id.btnCancel);


        calculator();
    }
    public void calculator(){
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double oldNum, newNum, used, rPayment, dPayment, dollar, payment;
                oldNum=Double.parseDouble(edOldNum.getText().toString());
                newNum=Double.parseDouble(edNewNum.getText().toString());
                used=newNum-oldNum;
                DecimalFormat t = new DecimalFormat("#,###.00");
                implementWaterInterface ob = new implementWaterInterface();
                payment=ob.paymentInRiel(used);
                rPayment= ob.totalPayment(payment, 20000);
                dPayment=ob.paymentInDollar(rPayment);
                edPayment.setText(t.format(payment)+ " Riels");
                edRPayment.setText(t.format(rPayment) + " Riels");
                edDPayment.setText(t.format(dPayment)+ " Dollar");
                edUsed.setText(t.format(used) + " m3");
                edMaintenance.setText("+ 20000");
            }
        });
    }
}