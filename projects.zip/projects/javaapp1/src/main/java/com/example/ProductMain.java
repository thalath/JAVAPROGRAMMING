package com.example;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ProductMain {
    public ProductMain(){
        List<Product> list = readList();

        List<Product> found = list.stream().filter(x -> x.getTitle().toLowerCase().contains("Gold".toLowerCase())).toList();
        found.forEach(x -> System.out.println(x + "\n"));
    }

    public List<Product> readList(){
        List<Product> list = new ArrayList<>();
        try {
            URI uri = new URI("https://fakestoreapi.com/products");
            String content = IOUtils.toString(uri, "UTF-8");
            list = new Gson().fromJson(content, new TypeToken<List<Product>>(){  
            }.getType());

        } catch (URISyntaxException ex) {
            System.out.println("Error: ..... ");
        } catch (IOException e) {
            System.out.println("Error: No internet or netword");
        }
        return list;

    }

}
