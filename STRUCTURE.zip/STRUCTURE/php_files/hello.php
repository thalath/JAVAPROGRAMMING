<?PHP
$num = [3, 1, 2, 4];
print_r($num);

foreach($num as $item) {
    echo "item = $item \n";
}