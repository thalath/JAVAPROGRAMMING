<?PHP
$student = ["id" => 101, "name" => "Sok", "score" => 75.5];
$id = $student["id"];
$name = $student["name"];
$score = $student["score"];

print_r($id . "\n");
print_r($name . "\n");
print_r($score . "\n");

print_r($student);

// indexed array
$fruits = ["apple", "coconut", "pear"];
$apple = $fruits[0];
$coconut = $fruits[1];
$pear = $fruits[2];

print_r($fruits);