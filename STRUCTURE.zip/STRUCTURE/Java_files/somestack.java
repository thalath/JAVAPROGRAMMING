import java.util.Stack;

public class somestack {
    public static void main(String[] args) {
        Stack<Integer> num = new Stack<Integer>();
        num.push(5);
        num.push(2);
        num.push(4);
        num.push(1);
        num.push(6);
        num.push(3);
        System.out.println(num);

        int x = num.pop();
        System.out.println(x);
        System.out.println(num);

        x = num.pop();
        System.out.println(x);
        System.out.println(num);

        x = num.pop();
        System.out.println(x);
        System.out.println(num);

        x = num.pop();
        System.out.println(x);
        System.out.println(num);

        x = num.pop();
        System.out.println(x);
        System.out.println(num);
        
        x = num.pop();
        System.out.println(x);
        System.out.println(num);
    }
}
