

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class final_linst_integer{
    private final_linst_integer(){
        List<Integer> arr = new ArrayList<>(Arrays.asList(7,2,1,3,4,5,6));

        // Sorted an array from small to big
        List<Integer> minSorted = arr.stream()
                                     .sorted((a,b) -> a.compareTo(b))
                                     .toList();
        System.out.print("sorted small to big: ");
        minSorted.forEach(x -> System.out.print(x + ", "));
        System.out.println();

        // Sorted an array from big to small
        List<Integer> maxSorted = arr.stream()
                                     .sorted((a,b) -> b.compareTo(a))
                                     .toList();
        System.out.print("Sorted big to small: ");
        maxSorted.forEach(x -> System.out.print(x + ", "));
        System.out.println();

        // Filter all even numbers
        List<Integer> even = arr.stream()
                                .filter(a -> (a%2 == 0))
                                .toList();
        System.out.print("Array even number: ");
        even.forEach(x -> System.out.print(x + ", "));
        System.out.println();

        // Filter all even numbers
        List<Integer> odd = arr.stream()
                                .filter(a -> (a%2 != 0))
                                .toList();
        System.out.print("Array odd number: "); 
        odd.forEach(x -> System.out.print(x + ", "));
        System.out.println();

        // Find The minimum of arr
        int findMin = Collections.min(arr);
        System.out.println("The minimum: " + findMin);


        // Find the maximum of arr
        int findMax = Collections.max(arr);
        System.out.println("the maximum: " + findMax);

        String convert = arr.stream().map(String::valueOf).collect(Collectors.joining(", "));
        System.out.println("String: " + convert);
        
    }

    public static void main(String[] args) {
        new final_linst_integer();
    }
}