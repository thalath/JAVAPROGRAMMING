

public class find_array_max {
    public static void main(String[] args) {
        int [] numbers = {5, 4, 3, 2, 6, 1, 8, 10, 7, 9};
        int max = numbers[0];
        for (int index = 0; index < numbers.length; index++) {
            if (numbers[index] > max) {
                max = numbers[index];
            }
        }
        System.out.println("Max = " + max);
    }
}
