import java.util.Arrays;
import java.util.List;

public class module_sorted {
    public static void main(String[] args) {
        List<Integer> num = Arrays.asList(5, 4, 3, 7, 1, 2, 8, 10, 9, 6);
        num.sort((a, b) -> a.compareTo(b));
        num.forEach((x) -> System.out.println(x));
    }
}
