import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Comparator;

public class ArrayListProduct {
  public static void main(String[] args) {
    ArrayList<Product> list = ProductData.getList();
    System.out.println("\ndisplay all products: ");
    list.forEach(System.out::println);

    //sorted by products price
    System.out.println("\nSorted by product's price: ");
    List<Product> p1  = list.stream().sorted(Comparator.comparing(a -> a.price)).toList();
    p1.forEach(System.out::println);

    // find samsung products
    System.out.println("\nFind Samsung Products: ");
    List <Product> findSamsung = list.stream()
                                     .filter(a -> a.title.contains("Samsung"))
                                     .toList();
    findSamsung.forEach(System.out::println);

    //find voter over 3000 and dis over 30 in products
    List <Product> find_dis = list.stream()
                                  .filter(a -> a.voter > 300 && 
                                               a.discount > 30)
                                  .toList();
                                  System.out.println("\nFind Voter and dis over 300 and 30 of products: ");
    find_dis.forEach(System.out::println);

  }
}

class ProductData {
  public static ArrayList<Product> getList() {
    return new ArrayList<>(Arrays.asList(
        new Product(1001, "iPhone 14 Pro", 999.99, 4.8, 1200, 50.0),
        new Product(1002, "Samsung Galaxy S22", 899.50, 4.5, 980, 70.0),
        new Product(1003, "MacBook Air M2", 1099.99, 4.9, 800, 100.0),
        new Product(1004, "iPad Pro 11\"", 799.00, 4.7, 600, 60.0),
        new Product(1005, "Sony WH-1000XM5", 349.99, 4.6, 400, 30.0),
        new Product(1006, "Dell XPS 13", 950.00, 4.4, 520, 80.0),
        new Product(1007, "Lenovo ThinkPad X1", 999.00, 4.3, 410, 90.0),
        new Product(1008, "Samsung Galaxy Tab S8", 699.99, 4.5, 430, 40.0),
        new Product(1009, "Bose QuietComfort Earbuds", 279.00, 4.6, 300, 25.0),
        new Product(1010, "Asus ROG Phone 6", 849.00, 4.8, 220, 50.0),
        new Product(1011, "OnePlus 10 Pro", 749.00, 4.4, 340, 45.0),
        new Product(1012, "Google Pixel 7", 699.00, 4.7, 510, 55.0),
        new Product(1013, "Xiaomi 12 Pro", 650.00, 4.3, 270, 60.0),
        new Product(1014, "Realme GT 2", 499.00, 4.1, 150, 35.0),
        new Product(1015, "iMac 24\"", 1299.99, 4.9, 280, 120.0),
        new Product(1016, "HP Spectre x360", 1150.00, 4.5, 390, 100.0),
        new Product(1017, "LG UltraFine Monitor", 699.99, 4.6, 210, 70.0),
        new Product(1018, "Microsoft Surface Pro 9", 899.99, 4.4, 320, 85.0),
        new Product(1019, "Amazon Echo Show 10", 249.99, 4.2, 180, 20.0),
        new Product(1020, "Anker PowerCore Power Bank", 59.99, 4.7, 800, 10.0)));
  }
}

class Product {
  Integer id;
  String title;
  Double price;
  Double rate;
  Integer voter;
  Double discount;

  public Product(int id, String title, double price, double rate, int voter, double discount) {
    this.id = id;
    this.title = title;
    this.price = price;
    this.rate = rate;
    this.voter = voter;
    this.discount = discount;
  }

  @Override
  public String toString() {
    return "Product [id=" + id + ", title=" + title + ", price=" + price + ", rate=" + rate + ", voter=" + voter
        + ", discount=" + discount + "]";
  }
  
}
