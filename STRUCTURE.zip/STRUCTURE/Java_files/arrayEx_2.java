public class arrayEx_2 {
    public static void main(String[] args) {
        Student s1 = new Student(101, "Sok", 78, 65, 55);
        Student s2 = new Student(101, "Sao", 78, 65, 55);
        System.out.println("Total = " + s1.total());
        System.out.println("Average = " + s2.average());
    }

}

class Student {
        int sid;
        String name;
        double math;
        double english;
        double khmer;

        public Student(int sid, String name, double math, double english, double khmer) {
            this.sid = sid;
            this.name = name;
            this.math = math;
            this.english = english;
            this.khmer = khmer;
        }

        double total(){
            return math + english + khmer;
        }

        double average(){
            return total() / 3;
        }
}