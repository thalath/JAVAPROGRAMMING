public class assignment_arr {
    public static void main(String[] args) {

        
        System.out.println("\n      ------Homework--------");
        //1. add first, 3 -> output: { 3, 4, 2, 1 }
        int[] arr1 = { 4, 2, 1 };
        int[] newArr = new int[arr1.length + 1];
        // transfers array
        System.out.print("\n1. Add \"3\" to the first index of {");
        for(int index = 0; index < arr1.length; index++){
            System.out.print(arr1[index] + ", ");
        }
        System.out.println("}");
        System.arraycopy(arr1, 0, newArr, 1, arr1.length);
        newArr[0] = 3; // add num 3 to the first index after transfers data
        System.out.print("after Added \"3\" to the first index: ");
        for(int index = 0; index < newArr.length; index++){
            System.out.print(newArr[index]+ " ");
        }
        System.out.println("\n");
        
        
        //2. remove last, 5 -> { 3, 4, 2, 1, 5 }
        int[] arr2 = {4, 2, 1, 5};
        int[] newArr2 = new int[arr2.length - 1];
        System.out.print("2. Remove \"5\" at last of  {");
        for(int index = 0; index < arr2.length; index++){
            System.out.print(arr2[index] + ", ");
        }
        System.out.println("}");
        System.arraycopy(arr2, 0, newArr2, 0, newArr2.length);
        System.out.print("After removed \"5\"of the last index: ");
        for(int index = 0; index < newArr2.length; index++){
            System.out.print(newArr2[index]+ " ");
        }
        System.out.println("\n");


        //3. reverse, { 5, 1, 2, 4, 3 }
        int[] arr3 = {5, 1, 2, 4, 3,};
        int start = 0;
        int end = arr3.length - 1;
        System.out.print("3. Reverse {");
        for(int index = 0; index < arr3.length; index++){
            System.out.print(arr3[index] + ", ");
        }
        System.out.println("}");
        while(start < end){
            int temp = arr3[start];
            arr3[start] = arr3[end];
            arr3[end] = temp;
            start++;
            end--;
        }
        System.out.print("After reversed: ");
        for(int index= 0; index < arr3.length; index++){
            System.out.print(arr3[index]+ " ");
        }
        
    }   
    
}
