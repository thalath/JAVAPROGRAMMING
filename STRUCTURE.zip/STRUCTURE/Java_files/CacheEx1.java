import java.util.HashMap;

public class CacheEx1 {
    public static void main(String[] args){
        new CacheEx1();
    }
    public CacheEx1(){
        NumberCacher cacher = new NumberCacher();
        long s1 = sum(4_000_000_000L);
        System.out.println("s1 = " + s1);
        for(int index = 0; index < 100; index++){
            cacher.sum(4_000_000_000L);
            System.out.println("s1 = " + s1);
        }
    }

    long sum(long max){
        long total = 0;
        for(long index = 0; index < max; index++){
            total += index;
        }
        return total;
    }
}
 
class NumberCacher {
    HashMap<Long, Long> cache = new HashMap<>();
    long sum(long max){
        if (cache.containsKey(max)){
            return cache.get(max);
        }else {
            long total = realSum(max);
            cache.put(max, total);
            return total;
        }
    }

    long realSum(long max){
        long total = 0;
        for(long i = 0; i < max; i++){
            total += i;
        }
        return total;
    }
}