public class find_max {
    public static void main(String[] args) {
        new find_max();
    }

    public find_max() {
        // find the maximum and minimum of three numbers
        // using the ternary operator
        int a = 25, b = 10, c = 13;
        int max = a;
            max = max < b ? b : max;
            max = max < c ? c : max;
            System.out.println("max = " + max);

        int min = a;
            min = min > b ? b : min;
            min = min > c ? c : min;
            System.out.println("min = " + min);
    }
}
