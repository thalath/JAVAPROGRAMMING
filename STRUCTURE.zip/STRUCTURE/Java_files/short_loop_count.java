// package Java_files;

public class short_loop_count {
    public static void main(String[] args) {
        int[] nums = {77, 1, 4, 5, 6, 35, 25, 9, 8, 15, 10, 7, 45, 55, 2};
        int max = nums[nums.length - 1];
        int count = 0;
        for(int index = 0; index < nums.length - 1; index+=2) {
            if ( nums[index + 1] > max) {
                max = nums[index + 1];
            }
            count++;
        }
        System.out.println("counter = " + count);
        System.out.println("max = " + max);
    }
}
