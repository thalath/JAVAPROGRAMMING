public class remove_arr {
    public static void main(String[] args) {
        int[] arr = {4, 2, 1, 3, 5, 6, 7};
        int[] arr2 = new int[arr.length + 1];

        
        for (int index = 0; index < arr.length; index++){
            arr2[index] = arr[index];
        }


        int newNumber = 8;
        System.out.print("Before delete frist element of array: ");
        arr2[arr2.length - 1] = newNumber;
        for(int index = 0; index < arr2.length; index++){
            System.out.print(arr2[index] + ", ");
        }


        System.out.println();
        System.out.print("After deleted first element of array: ");
        
        int[] arr3 = new int[arr2.length - 1];
        for(int index = 1; index < arr2.length; index++){
            arr3[index - 1] = arr2[index];
        }

        for(int index = 0; index < arr3.length; index++){
            System.out.print(arr3[index] + ", ");
        }

    }
}
