// import java.util.EmptyStackException;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;
import java.util.Queue;

public class somequeue {
    public static void main(String[] args) {
        Queue<String> pool = new PriorityQueue<>();
        try{
            pool.add("Computer A");
            pool.add("Computer B");
            pool.add("Computer C");
            pool.add("Computer D");
            System.out.println(pool);

            String rem = pool.remove();
            System.out.println(rem);
            System.out.println(pool);

            rem = pool.remove();
            System.out.println(rem);
            System.out.println(pool);

            rem = pool.remove();
            System.out.println(rem);
            System.out.println(pool);

            rem = pool.remove();
            System.out.println(rem);
            System.out.println(pool);

            rem = pool.remove();
            System.out.println(rem);
            System.out.println(pool);
        }catch(NoSuchElementException e){
            System.out.println("Queue is Empty.");
        }
    }
}
