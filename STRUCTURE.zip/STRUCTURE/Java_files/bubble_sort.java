public class bubble_sort {
    public static void main(String[] args) {
        int[] numbers = {40, 10, 11, 54, 73, 5, 2, 4};
        int temp;
        for(int rows = 0; rows < numbers.length - 1; rows++) {
            for(int cols = 0; cols < numbers.length - rows - 1; cols++) {
                if (numbers[cols] > numbers[cols + 1]){
                    temp = numbers[cols];
                    numbers[cols] = numbers[cols + 1];
                    numbers[cols + 1] = temp;
                }
            }
        }

        for(int index = 0; index < numbers.length; index++) {
            System.out.print(numbers[index] + ", ");
        }
    }
}
