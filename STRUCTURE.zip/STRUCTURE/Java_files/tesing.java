
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class tesing{
  public static void main(String[] args) {
    List<Integer> numbers = new ArrayList<>(Arrays.asList(7,2,1,3,4,5,6));

    // 1 sorted from small to big
    List<Integer> sortedStoB = numbers.stream()
                                      .sorted((a,b) -> a.compareTo(b))
                                      .toList();

    sortedStoB.forEach(a -> System.out.print(a + ", "));

    List<Integer> sortedBtoS = numbers.stream()
      
  }
}