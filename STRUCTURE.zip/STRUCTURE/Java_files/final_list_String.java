
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class final_list_String {
    private final_list_String(){
        List<String> products = new ArrayList<>(
                                Arrays.asList("Student", "Graduate Student", "Teacher"));

        // Sorted from A to Z
        List<String> sortAtoZ = products.stream()
                                        .sorted((a,z) -> a.compareTo(z))
                                        .toList();
        sortAtoZ.forEach(x -> System.out.println(x));
        System.out.println();

        //sorted from Z to A
        List<String> sortedZtoA = products.stream()
                                          .sorted((a,z) -> z.compareTo(a))
                                          .toList();
        sortedZtoA.forEach(a -> System.out.println(a));
        System.out.println();

        // select any item that has Student
        List<String> selectItem = products.stream()
                                          .filter(a -> a.toLowerCase().contains("Student".toLowerCase()))
                                          .toList();
        selectItem.forEach(a -> System.out.println(a));
        System.out.println();

        // count each items
        for(String item : products){
            int len = item.length();
            System.out.println("The length of "+item+" is "+len+"");
        }

        // Add Norton before each words
        List<String> addNorton = products.stream()
                                         .map(a -> "Norton "+ a)
                                         .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
        addNorton.forEach(a -> System.out.println(a));


        products.replaceAll(s -> "Norton " + s);
        System.out.println(products);

        Map<String, Integer> lengths = products.stream().collect(Collectors.toMap(Function.identity(), String::length));
        System.out.println(lengths);
    }
    public static void main(String[] args) {
        new final_list_String();
    }
}
