public class OOPEx1 {
    public static void main(String[] args) {

        Product ob = new Product(101, "Obstacle", 1444.550, 3.15);
        System.out.println(ob);
    }
    
}

class Product {
    Integer id;
    String title;
    Double price;
    Double rate;
    public Product(int id, String title, double price, double rate) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.rate = rate;
    }
    @Override
    public String toString() {
        return "Product [id=" + id + ", title=" + title + ", price=" + price + ", rate=" + rate + "]";
    }

    
}