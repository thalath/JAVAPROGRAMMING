#include <iostream>
using namespace std;

class Person{
    private:
        int id;
        string title;
        double price;
        string description;
        string 

};

int main(){
    cout << "Hello world";

    return false;
}