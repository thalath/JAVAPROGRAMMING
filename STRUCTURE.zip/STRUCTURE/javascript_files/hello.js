var name = "Hello world"
console.log(dir(name))