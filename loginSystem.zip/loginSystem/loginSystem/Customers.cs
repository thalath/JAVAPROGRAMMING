﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace loginSystem
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFirstName.Text) || string.IsNullOrEmpty(txtLastName.Text) || 
                string.IsNullOrEmpty(txtAddress.Text) || string.IsNullOrEmpty(txtEmail.Text) ||
                string.IsNullOrEmpty(txtPhone.Text))
            {
                showMessage("Please enter your own information into the box");
            }
            else
            {
                string firstName = txtFirstName.Text;
                string lastName = txtLastName.Text;
                string address = txtAddress.Text;
                string email = txtEmail.Text;
                string phone = txtPhone.Text;
                string source = "Data Source=Localhost; Initial Catalog=LoginSystem; Integrated Security=True";
                SqlConnection conn = new SqlConnection(source);
                conn.Open();

                string query = "insert into Customers(FirstName, LastName, email, phone, Address) values('"+firstName+"', '"+lastName+"', '"+email+"', '"+phone+"','"+address+"')";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();

                conn.Close();
                showMessage("Your Information has saved into system...!");
            }
        }

        private void showMessage(string sms)
        {
            MessageBox.Show(sms, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
