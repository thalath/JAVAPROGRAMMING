﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace loginSystem
{
    internal class Salaryfunc : Interface1
    {
        public double netSalaryFunc(double grossSalary, double tax)
        {
            return grossSalary - tax;
        }

        public double taxFunc(double grossTax)
        {
            double result = 0;
            if(grossTax >= 0 && grossTax < 1500001)
            {
                result = 0;
            }else if(grossTax >= 1500001 && grossTax < 2000001)
            {
                result = (grossTax * 0.05) - 75000; 
            }else if(grossTax >= 2000001 && grossTax < 8500001)
            {
                result = (grossTax * 0.1) - 175000;
                
            }else if(grossTax >= 8500001 && grossTax < 12500001)
            {
                result = (grossTax - 0.15) - 600000;
            }else if(grossTax >= 12500001)
            {
                result = (grossTax * 0.2) - 1225000;
            }

            return result;
        }
    }
}
