﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loginSystem
{
    public partial class Taxcalculate : Form
    {
        public Taxcalculate()
        {
            InitializeComponent();
            txtTax.ReadOnly= true;
            txtNetSalary.ReadOnly= true;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            double grossSalary, netSalary, tax = 0;
            if (string.IsNullOrEmpty(txtGrossSalary.Text))
            {
                sms("Please input the value into the texBox.");
            }else
            {
                grossSalary = Double.Parse(txtGrossSalary.Text);
                Salaryfunc obj = new Salaryfunc();
                tax = obj.taxFunc(grossSalary);
                netSalary = obj.netSalaryFunc(grossSalary, tax);
                txtTax.Text = tax.ToString(); 
                txtNetSalary.Text = netSalary.ToString();
            }
        }

        public void sms(string sms){
            MessageBox.Show(sms, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
