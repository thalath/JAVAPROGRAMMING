﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loginSystem
{
    internal interface Interface1
    {
        double netSalaryFunc(double grossSalary, double tax);
        double taxFunc(double grossTax);
    }
}
